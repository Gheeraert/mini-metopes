Documentation d'usage OpenEdition Journals
========================================================

La plateforme OpenEdition Journals utilise Lodel 1 et le schema TEI OpenEdition 1.6.3 documenté à cette adresse : https://tei-openedition.readthedocs.io/fr/latest/
