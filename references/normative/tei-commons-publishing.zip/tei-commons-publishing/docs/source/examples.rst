Fichiers exemples
===============================================

- Exemple de fichier TEI Commons Publishing OpenEdition pour l'import dans Lodel 2 : `lorem_ipsum_commons.openedition.tei.xml <_static/lorem_ipsum_commons.openedition.tei.xml>`_




