Elements et Attributs communs TEI Commons Publishing 
####################################################################

.. warning::

      Cette partie de la documentation a été générée automatique à partir du fichier ODD.


.. raw:: html
   :file: _static/commons-publishing-fr.html


